bl_info = {
    "name": "API New Ear",
    "description": "Generates a human ear and customizes it",
    "author": "Jac Petit-Jean-Boret",
    "version": (1,0),
    "blender": (2, 80, 0),
    "location": "View3D",
    "warning": '', 
    "doc_url": "",
    "category": "3D View",
    "support": 'COMMUNITY',
}

import bpy, math, os
from bpy.app.handlers import persistent
from bpy.types import Panel, Operator, AddonPreferences, PropertyGroup
from bpy.props import FloatProperty, StringProperty, PointerProperty, EnumProperty, BoolProperty
from mathutils import *
from bpy_extras.io_utils import ExportHelper, ImportHelper

#-----------------------------------------------------------------------------------------
#Append collections
#bpy.types.Collection
if not ("Coll all") in bpy.data.collections :
    path = "E:\Projets\ear\Ear-reference.blend\\Collection\\"
    object_name = "Coll all"
    bpy.ops.wm.append(filename=object_name, directory=path)

#Don't display disturbancies
bpy.context.area.type = 'VIEW_3D'
bpy.context.space_data.overlay.show_cursor = False
bpy.context.space_data.overlay.show_bones = False
bpy.context.space_data.overlay.show_outline_selected = False
bpy.context.space_data.overlay.show_relationship_lines = False
bpy.context.space_data.overlay.show_object_origins = False



#Case Blender uses its damn automatic renaming
for kee in bpy.data.shape_keys :
    if kee.name.startswith("Key") :
        mykey = kee
for rig in bpy.data.objects:
    if rig.name.startswith("Rig-ear") :
        myrig = rig
for ear in bpy.data.objects :
    if ear.name.startswith("Ear") :
        myear = ear

bpy.data.objects[myrig.name].hide_viewport = True       
#bpy.ops.hide.arrows()
#-----------------------------------------------------------------------------------------
def menu_func_import(self, context):
    self.layout.operator(ImportSomeData.bl_idname, text="Text Import Operator")

def menu_func_export(self, context):
    self.layout.operator(ExportSomeData.bl_idname, text="Text Export Operator")
    
#------------------DEF SHAPEKEYS----------------------------------------------------------
#shapekeys lobule
def update_lobh(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["lobh"].value = bpy.data.objects[myear.name].my_lobh

def update_lobno(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["lobno"].value = bpy.data.objects[myear.name].my_lobno
    
def update_lobt(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["lobt"].value = bpy.data.objects[myear.name].my_lobt
    
#--------------------------    
#shapekeys concavity, antihelix_depth, anithelix rear
def update_conca(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["conca"].value = bpy.data.objects[myear.name].my_conca

def update_antid(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["antid"].value = bpy.data.objects[myear.name].my_antid
    
def update_antir(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["antir"].value = bpy.data.objects[myear.name].my_antir

#--------------------------
#shapekeys tubercle helix thickness, helix protrusion
def update_tuber(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["tuber"].value = bpy.data.objects[myear.name].my_tuber

def update_helixt(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["helixt"].value = bpy.data.objects[myear.name].my_helixt
    
def update_helixp(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["helixp"].value = bpy.data.objects[myear.name].my_helixp
    
#--------------------------
#shapekeys tragus
def update_tragh(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["tragh"].value = bpy.data.objects[myear.name].my_tragh

def update_tragw(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["tragw"].value = bpy.data.objects[myear.name].my_tragw
    
def update_tragt(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["tragt"].value = bpy.data.objects[myear.name].my_tragt

#--------------------------
#shapekey crease
def update_notch(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["notch"].value = bpy.data.objects[myear.name].my_notch

#shapekey lobule notch
def update_antin(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["antin"].value = bpy.data.objects[myear.name].my_antin

#shapekey antitragus
def update_antit(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["antit"].value = bpy.data.objects[myear.name].my_antit
    
#shapekey tubercle
def update_tuber(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["tuber"].value = bpy.data.objects[myear.name].my_tuber    
    
#shapekey rear protrusion      
def update_protr(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["protr"].value = bpy.data.objects[myear.name].my_protr      
    
#shapekey double antitragus      
def update_anti2(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["anti2"].value = bpy.data.objects[myear.name].my_anti2    
    
#shapekey lobule midcrease    
def update_lobcr(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["lobcr"].value = bpy.data.objects[myear.name].my_lobcr 
    
#shapekey back crease    
def update_rearc(self, context) :
    bpy.data.shape_keys[mykey.name].key_blocks["rearc"].value = bpy.data.objects[myear.name].my_rearc


#-----------------------------------------------------------------------------------------
#BONES
#ear proportions    
def update_mainh(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Main"]  
    main_bone.scale[0] =  rig.my_mainh

def update_mainw(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Main"]  
    main_bone.scale[1] =  rig.my_mainw

def update_maint(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Main"]  
    main_bone.scale[2] =  rig.my_maint

#--------------------------
#bone rotations    
def update_mainz(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Main"]  
    main_bone.rotation_quaternion[1] =  math.radians(rig.my_mainz)

def update_mainy(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Main"]  
    main_bone.rotation_quaternion[3] =  math.radians(rig.my_mainy)

def update_mainx(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Main"]  
    main_bone.rotation_quaternion[2] =  math.radians(rig.my_mainx)

#--------------------------    
#bone deform top
def update_topx(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Top"]  
    main_bone.rotation_quaternion[1] =  math.radians(rig.my_topx)
    
def update_topy(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Top"]  
    main_bone.rotation_quaternion[2] =  math.radians(rig.my_topy)
    
def update_topz(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Top"]  
    main_bone.rotation_quaternion[3] =  math.radians(rig.my_topz)

#--------------------------
#bone deform bottom    
def update_bottomx(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Bottom"]  
    main_bone.rotation_quaternion[3] =  math.radians(rig.my_bottomx)

def update_bottomy(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Bottom"]  
    main_bone.rotation_quaternion[1] =  math.radians(rig.my_bottomy)

def update_bottomz(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Bottom"]  
    main_bone.rotation_quaternion[2] =  math.radians(rig.my_bottomz)

#--------------------------
#bone deform rear    
def update_rearx(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Rear"]  
    main_bone.rotation_quaternion[2] =  math.radians(rig.my_rearx)

def update_reary(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Rear"]  
    main_bone.rotation_quaternion[3] =  math.radians(rig.my_reary)

def update_rearz(self, context) :
    rig = bpy.data.objects['Rig-ear']
    bpy.context.view_layer.objects.active = rig
    main_bone = rig.pose.bones["Rear"]  
    main_bone.rotation_quaternion[1] =  math.radians(rig.my_rearz)

#-------------------------------
#import export tralala
def read_some_data(context, filepath):
    f = open(filepath, 'r', encoding='utf-8')
    loadmodel = f.read()
    f.close()
    # would normally load the data here
    sl = [float(idx) for idx in loadmodel.split('\n')]
    bo = bpy.data.objects['Rig-ear']
    sk = bpy.data.objects[myear.name]
    bo.my_mainh=sl[0]
    bo.my_mainw=sl[1] 
    bo.my_maint=sl[2] 
    bo.my_mainz=sl[3]
    bo.my_mainy=sl[4]
    bo.my_mainx=sl[5] 
    bo.my_topx=sl[6]
    bo.my_topy=sl[7]
    bo.my_topz=sl[8]
    bo.my_bottomx=sl[9]
    bo.my_bottomy=sl[10]
    bo.my_bottomz=sl[11]
    bo.my_rearx=sl[12]
    bo.my_reary=sl[13]
    bo.my_rearz=sl[14]
    sk.my_lobh=sl[15]
    sk.my_lobno=sl[16]
    sk.my_lobt=sl[17]
    sk.my_conca=sl[18]
    sk.my_tuber=sl[19]
    sk.my_protr=sl[20]
    sk.my_antid=sl[21]
    sk.my_antir=sl[22]
    sk.my_tragh=sl[23]
    sk.my_tragw=sl[24]
    sk.my_tragt=sl[25]
    sk.my_helixt=sl[26]
    sk.my_helixp=sl[27]
    sk.my_antit=sl[28]
    sk.my_notch=sl[29]
    sk.my_antin=sl[30]
    sk.my_rearc=sl[31]
    sk.my_anti2=sl[32]
    sk.my_lobcr=sl[33]
    return {'FINISHED'}

def write_some_data(context, filepath):
    bo = bpy.data.objects['Rig-ear']
    sk = bpy.data.objects[myear.name]
    model = [bo.my_mainh, bo.my_mainw, bo.my_maint, bo.my_mainz, bo.my_mainy, bo.my_mainx, bo.my_topx, bo.my_topy, bo.my_topz, bo.my_bottomx, bo.my_bottomy, bo.my_bottomz, bo.my_rearx, bo.my_reary, bo.my_rearz, sk.my_lobh, sk.my_lobno,sk.my_lobt, sk.my_conca, sk.my_tuber, sk.my_protr, sk.my_antid, sk.my_antir, sk.my_tragh, sk.my_tragw, sk.my_tragt, sk.my_helixt, sk.my_helixp, sk.my_antit, sk.my_notch, sk.my_antin, sk.my_rearc, sk.my_anti2, sk.my_lobcr]
    modeltext = "\n".join([str(i) for i in model]) 
    f = open(filepath, 'w', encoding='utf-8')
    f.write(modeltext)
    f.close()
    return {'FINISHED'}

#-----------------------------------------------------------------------------------------
#CLASSES    

#import ear settings
class ImportSomeData(Operator, ImportHelper):
    bl_idname = "import_test.some_data"  
    bl_label = "Import Ear settings"

    # ImportHelper mixin class uses this
    filename_ext = ".ear"
    filter_glob: StringProperty(
        default="*.ear",
        options={'HIDDEN'},
    )

    filepath = bpy.props.StringProperty(
        name="File Path",        
    )

    def execute(self, context):
        return read_some_data(context, self.properties.filepath)


    def invoke(self, context, event):
        self.filepath = bpy.context.scene.my_tool.workdir
        wm = context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

#--------------------------
#export ear settings
class ExportSomeData(Operator, ExportHelper):
    bl_idname = "export_test.some_data"
    bl_label = "Export Ear settings"

    # ExportHelper mixin class uses this
    filename_ext = ".ear"
    filter_glob: StringProperty(
        default="*.ear",
        options={'HIDDEN'},
    )
    filepath = bpy.props.StringProperty(
        name="File Path", 
    )

    def execute(self, context):
        return write_some_data(context, self.properties.filepath)
    
    def invoke(self, context, event):
        self.filepath = bpy.context.scene.my_tool.workdir
        wm = context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

#--------------------------
class LOADPRESET_PT_op(bpy.types.Operator):
    bl_idname = "load.preset"
    bl_label = "Load Preset"

    def execute(self, context):  
        bpy.ops.import_test.some_data('INVOKE_DEFAULT')
        return {'FINISHED'}    
      
   
#--------------------------
class SAVEPRESET_PT_op(bpy.types.Operator):
    bl_idname = "store.preset"
    bl_label = "Store Preset"

    def execute(self, context):   
        bpy.ops.export_test.some_data('INVOKE_DEFAULT')
        return {'FINISHED'}  
   

#-------------------------- ARROWS BONES ------------------------   
#Toggle Hide all arrows   
class HIDEA_PT_op(bpy.types.Operator):
    bl_idname = "hide.arrows"
    bl_label = "Hide arrows"

    def execute(self, context):    
        bpy.data.objects["01mainh"].hide_viewport=True
        bpy.data.objects["02mainw"].hide_viewport=True
        bpy.data.objects["03maint"].hide_viewport=True
        
        bpy.data.objects["04mainz"].hide_viewport=True
        bpy.data.objects["05mainy"].hide_viewport=True
        bpy.data.objects["06mainx"].hide_viewport=True
        
        bpy.data.objects["07topx"].hide_viewport=True
        bpy.data.objects["08topy"].hide_viewport=True
        bpy.data.objects["09topz"].hide_viewport=True
        
        bpy.data.objects["10bottomx"].hide_viewport=True
        bpy.data.objects["11bottomy"].hide_viewport=True
        bpy.data.objects["12bottomz"].hide_viewport=True
        
        bpy.data.objects["13rearx"].hide_viewport=True
        bpy.data.objects["14reary"].hide_viewport=True
        bpy.data.objects["15rearz"].hide_viewport=True
        
        
        bpy.data.objects["21lobh"].hide_viewport=True
        bpy.data.objects["22lobno"].hide_viewport=True
        bpy.data.objects["23lobt"].hide_viewport=True
        
        bpy.data.objects["24conca"].hide_viewport=True
        bpy.data.objects["25antid"].hide_viewport=True
        bpy.data.objects["26antir"].hide_viewport=True
        
        bpy.data.objects["27tuber"].hide_viewport=True
        bpy.data.objects["28helixt"].hide_viewport=True
        bpy.data.objects["29helixp"].hide_viewport=True
        
        bpy.data.objects["30tragh"].hide_viewport=True
        bpy.data.objects["31tragw"].hide_viewport=True
        bpy.data.objects["32tragt"].hide_viewport=True
        
        bpy.data.objects["33antit"].hide_viewport=True
        bpy.data.objects["34antin"].hide_viewport=True
        bpy.data.objects["35notch"].hide_viewport=True
        
        bpy.data.objects["36anti2"].hide_viewport=True
        bpy.data.objects["37lobcr"].hide_viewport=True
        
        bpy.data.objects["38protr"].hide_viewport=True
        bpy.data.objects["39rearc"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 01 Ear height 
class AMAINH_PT_op(bpy.types.Operator):
    bl_idname = "toggle.amainh"
    bl_label = "Toggle 01mainh"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["01mainh"].hide_viewport==True :
            bpy.data.objects["01mainh"].hide_viewport=False
        else: bpy.data.objects["01mainh"].hide_viewport=True
            
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 02 Ear width
class AMAINW_PT_op(bpy.types.Operator):
    bl_idname = "toggle.amainw"
    bl_label = "Toggle 02mainw"

    def execute(self, context):   
        bpy.ops.hide.arrows()
        if bpy.data.objects["02mainw"].hide_viewport==True :
            bpy.data.objects["02mainw"].hide_viewport=False
        else: bpy.data.objects["02mainw"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 03 Ear thickness 
class AMAINT_PT_op(bpy.types.Operator):
    bl_idname = "toggle.amaint"
    bl_label = "Toggle 03maint"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["03maint"].hide_viewport==True :
            bpy.data.objects["03maint"].hide_viewport=False
        else: bpy.data.objects["03maint"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------  
#Toggle Arrow 04 Ear Z rotation 
class AMAINZ_PT_op(bpy.types.Operator):
    bl_idname = "toggle.amainz"
    bl_label = "Toggle 04mainz"

    def execute(self, context):    
        bpy.ops.hide.arrows()
        if bpy.data.objects["04mainz"].hide_viewport==True :
            bpy.data.objects["04mainz"].hide_viewport=False
        else: bpy.data.objects["04mainz"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 05 Ear Y rotation 
class AMAINY_PT_op(bpy.types.Operator):
    bl_idname = "toggle.amainy"
    bl_label = "Toggle 05mainy"

    def execute(self, context):
        bpy.ops.hide.arrows() 
        if bpy.data.objects["05mainy"].hide_viewport==True :
            bpy.data.objects["05mainy"].hide_viewport=False
        else: bpy.data.objects["05mainy"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 06 Ear X rotation
class AMAINX_PT_op(bpy.types.Operator):
    bl_idname = "toggle.amainx"
    bl_label = "Toggle 06mainx"

    def execute(self, context):
        bpy.ops.hide.arrows()   
        if bpy.data.objects["06mainx"].hide_viewport==True :
            bpy.data.objects["06mainx"].hide_viewport=False
        else: bpy.data.objects["06mainx"].hide_viewport=True
        
        return{'FINISHED'}    
    
#--------------------------  
#Toggle Arrow 07 Top X rotation 
class ATOPX_PT_op(bpy.types.Operator):
    bl_idname = "toggle.atopx"
    bl_label = "Toggle 07topx"

    def execute(self, context):
        bpy.ops.hide.arrows()  
        if bpy.data.objects["07topx"].hide_viewport==True :
            bpy.data.objects["07topx"].hide_viewport=False
        else: bpy.data.objects["07topx"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 08 Top Y rotation 
class ATOPY_PT_op(bpy.types.Operator):
    bl_idname = "toggle.atopy"
    bl_label = "Toggle 08topy"

    def execute(self, context):
        bpy.ops.hide.arrows()   
        if bpy.data.objects["08topy"].hide_viewport==True :
            bpy.data.objects["08topy"].hide_viewport=False
        else: bpy.data.objects["08topy"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 09 Top Z rotation
class ATOPZ_PT_op(bpy.types.Operator):
    bl_idname = "toggle.atopz"
    bl_label = "Toggle 09topz"

    def execute(self, context):
        bpy.ops.hide.arrows() 
        if bpy.data.objects["09topz"].hide_viewport==True :
            bpy.data.objects["09topz"].hide_viewport=False
        else: bpy.data.objects["09topz"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------  
#Toggle Arrow 10 Bottom X rotation 
class ABOTTOMX_PT_op(bpy.types.Operator):
    bl_idname = "toggle.abottomx"
    bl_label = "Toggle 10bottomx"

    def execute(self, context):
        bpy.ops.hide.arrows() 
        if bpy.data.objects["10bottomx"].hide_viewport==True :
            bpy.data.objects["10bottomx"].hide_viewport=False
        else: bpy.data.objects["10bottomx"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 11 Bottom Y rotation 
class ABOTTOMY_PT_op(bpy.types.Operator):
    bl_idname = "toggle.abottomy"
    bl_label = "Toggle 11bottomy"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["11bottomy"].hide_viewport==True :
            bpy.data.objects["11bottomy"].hide_viewport=False
        else: bpy.data.objects["11bottomy"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 12 Bottom Z rotation
class ABOTTOMZ_PT_op(bpy.types.Operator):
    bl_idname = "toggle.abottomz"
    bl_label = "Toggle 12bottomz"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["12bottomz"].hide_viewport==True :
            bpy.data.objects["12bottomz"].hide_viewport=False
        else: bpy.data.objects["12bottomz"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------  
#Toggle Arrow 13 rear X rotation 
class AREARX_PT_op(bpy.types.Operator):
    bl_idname = "toggle.arearx"
    bl_label = "Toggle 13rearx"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["13rearx"].hide_viewport==True :
            bpy.data.objects["13rearx"].hide_viewport=False
        else: bpy.data.objects["13rearx"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 14 rear Y rotation 
class AREARY_PT_op(bpy.types.Operator):
    bl_idname = "toggle.areary"
    bl_label = "Toggle 14reary"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["14reary"].hide_viewport==True :
            bpy.data.objects["14reary"].hide_viewport=False
        else: bpy.data.objects["14reary"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 15 rear Z rotation
class AREARZ_PT_op(bpy.types.Operator):
    bl_idname = "toggle.arearz"
    bl_label = "Toggle 15rearz"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["15rearz"].hide_viewport==True :
            bpy.data.objects["15rearz"].hide_viewport=False
        else: bpy.data.objects["15rearz"].hide_viewport=True
        
        return{'FINISHED'}    


#--------------------------  ARROWS SHAPEKEYS ---------------------------- 
#Toggle Arrow 21 scale lobule height
class ALOBH_PT_op(bpy.types.Operator):
    bl_idname = "toggle.alobh"
    bl_label = "Toggle 21lobh"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["21lobh"].hide_viewport==True :
            bpy.data.objects["21lobh"].hide_viewport=False
        else: bpy.data.objects["21lobh"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 22 scale no lobule
class ALOBNO_PT_op(bpy.types.Operator):
    bl_idname = "toggle.alobno"
    bl_label = "Toggle 22lobno"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["22lobno"].hide_viewport==True :
            bpy.data.objects["22lobno"].hide_viewport=False
        else: bpy.data.objects["22lobno"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 23 scale lobule thickness
class ALOBT_PT_op(bpy.types.Operator):
    bl_idname = "toggle.alobt"
    bl_label = "Toggle 23lobt"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["23lobt"].hide_viewport==True :
            bpy.data.objects["23lobt"].hide_viewport=False
        else: bpy.data.objects["23lobt"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------
#Toggle Arrow 24 scale rear concavity
class ACONCA_PT_op(bpy.types.Operator):
    bl_idname = "toggle.aconca"
    bl_label = "Toggle 24conca"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["24conca"].hide_viewport==True :
            bpy.data.objects["24conca"].hide_viewport=False
        else: bpy.data.objects["24conca"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 25 scale antihelix depth
class AANTID_PT_op(bpy.types.Operator):
    bl_idname = "toggle.aantid"
    bl_label = "Toggle 25antid"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["25antid"].hide_viewport==True :
            bpy.data.objects["25antid"].hide_viewport=False
        else: bpy.data.objects["25antid"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 26 scale antihelix rear
class AANTIR_PT_op(bpy.types.Operator):
    bl_idname = "toggle.aantir"
    bl_label = "Toggle 26antir"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["26antir"].hide_viewport==True :
            bpy.data.objects["26antir"].hide_viewport=False
        else: bpy.data.objects["26antir"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------
#Toggle Arrow 27 scale rear concavity
class ATUBER_PT_op(bpy.types.Operator):
    bl_idname = "toggle.atuber"
    bl_label = "Toggle 27tuber"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["27tuber"].hide_viewport==True :
            bpy.data.objects["27tuber"].hide_viewport=False
        else: bpy.data.objects["27tuber"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 28 scale antihelix depth
class AHELIXT_PT_op(bpy.types.Operator):
    bl_idname = "toggle.ahelixt"
    bl_label = "Toggle 28helixt"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["28helixt"].hide_viewport==True :
            bpy.data.objects["28helixt"].hide_viewport=False
        else: bpy.data.objects["28helixt"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 29 scale antihelix rear
class AHELIXP_PT_op(bpy.types.Operator):
    bl_idname = "toggle.ahelixp"
    bl_label = "Toggle 29helixp"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["29helixp"].hide_viewport==True :
            bpy.data.objects["29helixp"].hide_viewport=False
        else: bpy.data.objects["29helixp"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------
#Toggle Arrow 30 scale tragus height
class ATRAGH_PT_op(bpy.types.Operator):
    bl_idname = "toggle.atragh"
    bl_label = "Toggle 30tragh"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["30tragh"].hide_viewport==True :
            bpy.data.objects["30tragh"].hide_viewport=False
        else: bpy.data.objects["30tragh"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 31 scale tragus width
class ATRAGW_PT_op(bpy.types.Operator):
    bl_idname = "toggle.atragw"
    bl_label = "Toggle 31tragw"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["31tragw"].hide_viewport==True :
            bpy.data.objects["31tragw"].hide_viewport=False
        else: bpy.data.objects["31tragw"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 32 scale tragus thickness
class ATRAGT_PT_op(bpy.types.Operator):
    bl_idname = "toggle.atragt"
    bl_label = "Toggle 32tragt"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["32tragt"].hide_viewport==True :
            bpy.data.objects["32tragt"].hide_viewport=False
        else: bpy.data.objects["32tragt"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------
#Toggle Arrow 33 scale tragus height
class AANTIT_PT_op(bpy.types.Operator):
    bl_idname = "toggle.aantit"
    bl_label = "Toggle 33antit"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["33antit"].hide_viewport==True :
            bpy.data.objects["33antit"].hide_viewport=False
        else: bpy.data.objects["33antit"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 34 scale tragus width
class AANTIN_PT_op(bpy.types.Operator):
    bl_idname = "toggle.aantin"
    bl_label = "Toggle 34antin"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["34antin"].hide_viewport==True :
            bpy.data.objects["34antin"].hide_viewport=False
        else: bpy.data.objects["34antin"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 35 scale lobule crease
class ANOTCH_PT_op(bpy.types.Operator):
    bl_idname = "toggle.anotch"
    bl_label = "Toggle 35notch"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["35notch"].hide_viewport==True :
            bpy.data.objects["35notch"].hide_viewport=False
        else: bpy.data.objects["35notch"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------
#Toggle Arrow 36 scale double antitragus
class AANTI2_PT_op(bpy.types.Operator):
    bl_idname = "toggle.aanti2"
    bl_label = "Toggle 36anti2"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["36anti2"].hide_viewport==True :
            bpy.data.objects["36anti2"].hide_viewport=False
        else: bpy.data.objects["36anti2"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 37 scale forelobule crease
class ALOBCR_PT_op(bpy.types.Operator):
    bl_idname = "toggle.alobcr"
    bl_label = "Toggle 37lobcr"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["37lobcr"].hide_viewport==True :
            bpy.data.objects["37lobcr"].hide_viewport=False
        else: bpy.data.objects["37lobcr"].hide_viewport=True
        
        return{'FINISHED'}    

#--------------------------    
#Toggle Arrow 38 scale back of the ear protrusion
class APROTR_PT_op(bpy.types.Operator):
    bl_idname = "toggle.aprotr"
    bl_label = "Toggle 38protr"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["38protr"].hide_viewport==True :
            bpy.data.objects["38protr"].hide_viewport=False
        else: bpy.data.objects["38protr"].hide_viewport=True
        
        return{'FINISHED'}   

#--------------------------    
#Toggle Arrow 39 scale back of the ear crease
class AREARC_PT_op(bpy.types.Operator):
    bl_idname = "toggle.arearc"
    bl_label = "Toggle 39rearc"

    def execute(self, context):
        bpy.ops.hide.arrows()
        if bpy.data.objects["39rearc"].hide_viewport==True :
            bpy.data.objects["39rearc"].hide_viewport=False
        else: bpy.data.objects["39rearc"].hide_viewport=True
        
        return{'FINISHED'} 
    


#---------------------- TOGGLE MISC -----------------------------------------      
#Toggle Manual and Info   
class MANUAL_PT_op(bpy.types.Operator):
    bl_idname = "toggle.manual"
    bl_label = "Toggle manual"

    def execute(self, context):
        if bpy.data.collections["Coll manual"].hide_viewport==True :
            bpy.data.collections["Coll manual"].hide_viewport=False
        else: bpy.data.collections["Coll manual"].hide_viewport=True
        
        return{'FINISHED'}    


#--------------------------    
#Toggle Oropedia    
class CAPTIONS_PT_op(bpy.types.Operator):
    bl_idname = "toggle.captions"
    bl_label = "Toggle captions"

    def execute(self, context):    
        if bpy.data.collections["Coll captions"].hide_viewport==True :
            bpy.data.collections["Coll captions"].hide_viewport=False
        else: bpy.data.collections["Coll captions"].hide_viewport=True
        
        return{'FINISHED'}     

#--------------------------    
#Toggle Legend    
class LEGEND_PT_op(bpy.types.Operator):
    bl_idname = "toggle.legend"
    bl_label = "Toggle legend"

    def execute(self, context):    
        if bpy.data.collections["Coll legend"].hide_viewport==True :
            bpy.data.collections["Coll legend"].hide_viewport=False
        else: bpy.data.collections["Coll legend"].hide_viewport=True
        
        return{'FINISHED'}     
    
#--------------------------      
#Toggle Subsurf 
class SUBSURF_PT_op(bpy.types.Operator):
    bl_idname = "toggle.subsurf"
    bl_label = "Toggle subsurf"

    def execute(self, context):   
        obj = bpy.data.objects[myear.name]
        bpy.context.view_layer.objects.active = obj 
        if obj.modifiers["Subdivision"].show_viewport == True :
            obj.modifiers["Subdivision"].show_viewport = False
        else: obj.modifiers["Subdivision"].show_viewport = True
        
        return{'FINISHED'}    
     
#--------------------------
#Get work directory
class MyProperties(PropertyGroup):

    workdir : StringProperty(
        name="",
        description="Path to Directory",
        default="",
        maxlen=1024,
        subtype='DIR_PATH')
        
#--------------------------
#Reset shapekeys and their sliders
class RESETKEYS_PT_op(bpy.types.Operator):
    bl_idname = "reset.regions"
    bl_label = "Reset Regions"

    def execute(self, context):    
        obj = bpy.data.objects[myear.name]
        bpy.context.view_layer.objects.active = obj
        bpy.data.shape_keys[mykey.name].key_blocks["lobh"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["lobno"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["lobt"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["conca"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["antid"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["antir"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["tuber"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["protr"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["tragh"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["tragw"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["tragt"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["helixt"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["helixp"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["antit"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["notch"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["antin"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["rearc"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["anti2"].value = 0
        bpy.data.shape_keys[mykey.name].key_blocks["lobcr"].value = 0
        
        obj.my_lobh = 0
        obj.my_lobno = 0
        obj.my_lobt = 0
        obj.my_conca = 0
        obj.my_antid = 0
        obj.my_antir = 0
        obj.my_tuber = 0
        obj.my_protr = 0
        obj.my_tragh = 0
        obj.my_tragw = 0
        obj.my_tragt = 0
        obj.my_helixt = 0
        obj.my_helixp = 0
        obj.my_antit = 0
        obj.my_notch = 0
        obj.my_antin = 0
        obj.my_rearc = 0
        obj.my_anti2 = 0
        obj.my_lobcr = 0
        return{'FINISHED'}   



#--------------------------
#Reset bones         
class RESET_PT_op(bpy.types.Operator):
    bl_idname = "reset.bones"
    bl_label = "Reset bones"

    
    def execute(self, context):        
        rig = bpy.data.objects['Rig-ear']
        bpy.context.view_layer.objects.active = rig
        bpy.ops.object.mode_set(mode='POSE')   
        bpy.ops.pose.select_all(action='SELECT')     
        bpy.ops.pose.transforms_clear()
        
        rig.my_mainh = 1.0
        rig.my_mainw = 1.0
        rig.my_maint = 1.0
        rig.my_mainz = 0
        rig.my_mainy = 0
        rig.my_mainx = 0
        rig.my_topz = 0
        rig.my_topy = 0
        rig.my_topx = 0
        rig.my_bottomz = 0
        rig.my_bottomy = 0
        rig.my_bottomx = 0
        rig.my_rearz = 0
        rig.my_reary = 0
        rig.my_rearx = 0
        return{'FINISHED'}   


#--------------------------
#Save settings
class MYTOOL_OT_write_data(bpy.types.Operator, ExportHelper):
    bl_idname = "mytool.write_data"
    bl_label = "Write data file"

#--------------------------
#save and export created model as stl mesh
class RESULTSTL_PT_op(bpy.types.Operator):
    bl_idname = "result.export"
    bl_label = "Result"
    rig = bpy.data.objects['Rig-ear']
    
    def execute(self, context): 
        obj = bpy.data.objects[myear.name]
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.modifier_remove(modifier="Subdivision")        
	bpy.ops.object.modifier_apply_as_shapekey(modifier="Armature")
        bpy.data.shape_keys[mykey.name].key_blocks["Armature"].value = 1.0
        bpy.ops.object.shape_key_add(from_mix=True)
        
        bpy.context.object.active_shape_key_index = 20
        bpy.data.shape_keys[mykey.name].key_blocks["Armature"].value = 1
        bpy.context.object.active_shape_key_index = 19

        x = 1
        while x < bpy.context.object.active_shape_key_index + 1 :
            bpy.ops.object.shape_key_remove(all=False)
        bpy.ops.object.parent_clear(type='CLEAR')

#------------------------------
#remove all unnecessary collections     
        name = "Coll arrows"
        remove_collection_objects = True
        coll = bpy.data.collections.get(name)
        if coll:
            if remove_collection_objects:
                obs = [o for o in coll.objects if o.users == 1]
                while obs:
                    bpy.data.objects.remove(obs.pop())
            bpy.data.collections.remove(coll)

        name = "Coll captions"
        remove_collection_objects = True
        coll = bpy.data.collections.get(name)
        if coll:
            if remove_collection_objects:
                obs = [o for o in coll.objects if o.users == 1]
                while obs:
                    bpy.data.objects.remove(obs.pop())
            bpy.data.collections.remove(coll)
            
        name = "Coll manual"
        remove_collection_objects = True
        coll = bpy.data.collections.get(name)
        if coll:
            if remove_collection_objects:
                obs = [o for o in coll.objects if o.users == 1]
                while obs:
                    bpy.data.objects.remove(obs.pop())
            bpy.data.collections.remove(coll)
            
        name = "Coll legend"
        remove_collection_objects = True
        coll = bpy.data.collections.get(name)
        if coll:
            if remove_collection_objects:
                obs = [o for o in coll.objects if o.users == 1]
                while obs:
                    bpy.data.objects.remove(obs.pop())
            bpy.data.collections.remove(coll)

#export

        filepath = bpy.context.scene.my_tool.workdir
        bpy.context.view_layer.objects.active = bpy.data.objects[myear.name]
        target_file = os.path.join(filepath, 'my_new_ear.stl')
        bpy.ops.export_mesh.stl(filepath=target_file,use_selection=True)

#remove the last collection to get a clear blend
        name = "Coll all"
        remove_collection_objects = True
        coll = bpy.data.collections.get(name)
        if coll:
            if remove_collection_objects:
                obs = [o for o in coll.objects if o.users == 1]
                while obs:
                    bpy.data.objects.remove(obs.pop())
            bpy.data.collections.remove(coll)
                
        return{'FINISHED'}
    
#--------------------------
#save the blend to append the created object later and export created model as stl mesh
class RESULTBL_PT_op(bpy.types.Operator):
    bl_idname = "result.keep"
    bl_label = "Result"
    rig = bpy.data.objects['Rig-ear']
    
    def execute(self, context): 
        if (myear.name) in bpy.data.objects : #stop if Ear was already saved
            obj = bpy.data.objects[myear.name]
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.modifier_remove(modifier="Subdivision")
            bpy.ops.object.modifier_apply_as_shapekey(modifier="Armature")
            bpy.data.shape_keys[mykey.name].key_blocks["Armature"].value = 1.0
            bpy.ops.object.shape_key_add(from_mix=True)
            
            bpy.context.object.active_shape_key_index = 20
            bpy.data.shape_keys[mykey.name].key_blocks["Armature"].value = 1
            bpy.context.object.active_shape_key_index = 19

            x = 1
            while x < bpy.context.object.active_shape_key_index + 1 :
                bpy.ops.object.shape_key_remove(all=False)
            bpy.ops.object.parent_clear(type='CLEAR')
 
            
#Remove unnecessary collections         
#            name = "Coll arrows"
#            remove_collection_objects = True
#            coll = bpy.data.collections.get(name)
#            if coll:
#                if remove_collection_objects:
#                    obs = [o for o in coll.objects if o.users == 1]
#                    while obs:
#                        bpy.data.objects.remove(obs.pop())
#                bpy.data.collections.remove(coll)
#
#            name = "Coll captions"
#            remove_collection_objects = True
#            coll = bpy.data.collections.get(name)
#            if coll:
#                if remove_collection_objects:
#                    obs = [o for o in coll.objects if o.users == 1]
#                    while obs:
#                        bpy.data.objects.remove(obs.pop())
#                bpy.data.collections.remove(coll)
#                
#            name = "Coll manual"
#            remove_collection_objects = True
#            coll = bpy.data.collections.get(name)
#            if coll:
#                if remove_collection_objects:
#                    obs = [o for o in coll.objects if o.users == 1]
#                    while obs:
#                        bpy.data.objects.remove(obs.pop())
#                bpy.data.collections.remove(coll)
#                        
#            name = "Coll legend"
#            remove_collection_objects = True
#            coll = bpy.data.collections.get(name)
#            if coll:
#                if remove_collection_objects:
#                    obs = [o for o in coll.objects if o.users == 1]
#                    while obs:
#                        bpy.data.objects.remove(obs.pop())
#                bpy.data.collections.remove(coll)
                        
                        
                        
#save as blend : unparent the ear, delete the rig and save the blend
            bpy.data.objects[myear.name].parent = None
            if (myrig.name) in bpy.data.objects :
                objs = bpy.data.objects
                objs.remove(objs[myrig.name], do_unlink = True)
            
            filepath = bpy.context.scene.my_tool.workdir

            bpy.context.view_layer.objects.active = bpy.data.objects[myear.name]
            target_file = bpy.path.abspath(os.path.join(filepath, 'my_new_ear.blend'))

            bpy.ops.wm.save_as_mainfile(filepath=target_file, check_existing=True,  relative_remap = False)

            return{'FINISHED'}
        
#-----------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------
#PANEL    
class EAR_PT_panel(bpy.types.Panel):
    bl_label = "API New Ear"
    bl_category = "Ear"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_idname = "my_panel"

    path : StringProperty(
        name="",
        description="Path to Directory",
        default="",
        maxlen=1024,
        subtype='DIR_PATH')
        
    def draw(self, context):
        layout = self.layout
        scn = context.scene
        row = layout.row()
        row.label(text="        Choose your work directory (best absolute path)")
        
        col = layout.column(align=True)
        col.prop(scn.my_tool, "workdir", text="")
        
        main_bone = bpy.data.objects[myrig.name].pose.bones["Main"]
        row = layout.row()
        row.operator('toggle.manual', text = "Toggle info")
        row.operator('toggle.captions', text = "Toggle Oropedia")
        row.operator('toggle.legend', text = "Toggle Legend")
        row.operator('hide.arrows', text = "Hide arrows help")
        row.operator('toggle.subsurf', text = "Toggle subsurf")
        box = layout.box()
        row = box.row()
        row.label(text="        Whole ear proportions and orientations")

#--------------------------------------------------------------------
#SLIDERS
#Sliders rig scalings row 1 (sliders 1 to 3)  
        sca = 0.2 #arrow button scale factor for a row of sliders
        row = box.row()
        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_mainh', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.amainh")
        
        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_mainw', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.amainw")

        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_maint', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.amaint")

#--------------------------
#Sliders rig rotations row 2 (sliders 4 to 6)   
        row = box.row()     
        if obj is not None:
            row.prop(obj, 'my_mainz', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.amainz")

        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_mainy', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.amainy")

        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_mainx', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.amainx")
        
#--------------------------            
#Sliders rig rotations top row 3 (sliders 7 to 9)
        row = box.row()     
        if obj is not None:
            row.prop(obj, 'my_topx', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.atopx")

        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_topy', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.atopy")
                     
        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_topz', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.atopz")
        
#--------------------------            
#Sliders rig rotations bottom row 4 (sliders 10 to 12)
        row = box.row() 
        if obj is not None:
            row.prop(obj, 'my_bottomx', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.abottomx")
        obj = bpy.data.objects[myrig.name]

        if obj is not None:
            row.prop(obj, 'my_bottomy', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.abottomy")
        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_bottomz', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.abottomz")

#--------------------------
#Sliders rig rotations rear row 5 (sliders 13 to 15)
        row = box.row() 
        if obj is not None:
            row.prop(obj, 'my_rearx', slider=True) 
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.arearx")           

        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_reary', slider=True)            
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.areary")
           
        obj = bpy.data.objects[myrig.name]
        if obj is not None:
            row.prop(obj, 'my_rearz', slider=True)            
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.arearz")
           
#--------------------------            
#Reset bones
        row = box.row()
        row.operator('reset.bones', text = "Reset proportions and orientations")

        
        box = layout.box()
        row=box.row()
        row.label(text="           Ear regions and specific shapes") 

#---------------------------------------------------------------------      
#Sliders shapekeys lobule  row 1 (sliders 21 to 23)   
        obj = bpy.data.objects[myear.name]
        row = box.row() 
        if obj is not None:
            row.prop(obj, 'my_lobh', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.alobh")

        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_lobno', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.alobno")        
        
        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_lobt', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.aconca")
        
#--------------------------
#Sliders shapekeys concavity, antihelix row 2 (sliders 24 to 26) 
        row = box.row() 
        if obj is not None:
            row.prop(obj, 'my_conca', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.aconca")
        

        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_antid', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.aantid")
        
        
        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_antir', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.aantir")
        

#Sliders tubercle helix thickness, helix row 3 (sliders 27 to 29) 
        row = box.row() 
        if obj is not None:
            row.prop(obj, 'my_tuber', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.atuber")

        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_helixt', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.ahelixt")        
        
        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_helixp', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.ahelixp")

#Sliders shapekeys tragus row 4 (sliders 30 to 32) 
        row = box.row() 
        if obj is not None:
            row.prop(obj, 'my_tragh', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.atragh")

        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_tragw', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.atragw")
        
        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_tragt', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.atragt")
        
#--------------------------
#Sliders shapekeys antitragus, lobule crease row 5 (sliders 33 to 35)    
        row = box.row() 
        if obj is not None:
            row.prop(obj, 'my_antit', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.aantit")
  
        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_antin', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.aantin")
                  
        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_notch', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.anotch")
              
#--------------------------
#Sliders shapekeys antitragus loc, lobule midcrease row 6 (sliders 36 to 37)  
        row = box.row() 
        if obj is not None:
            row.prop(obj, 'my_anti2', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.aanti2")
                        
        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_lobcr', slider=True)
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.alobcr")
        
#--------------------------            
#Sliders shapekey rear protrusion, root crease  row 7 (sliders 38 to 39)    
        row = box.row()      
        row.label(text="           Back of the ear") 
        row = box.row()  
        if obj is not None:
            row.prop(obj, 'my_protr', slider=True)   
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.aprotr")
                    
        obj = bpy.data.objects[myear.name]
        if obj is not None:
            row.prop(obj, 'my_rearc', slider=True)   
        sub = row.row()
        sub.scale_x = sca
        sub.operator("toggle.arearc")
        
#--------------------------
#Button Reset regions
        row = box.row() 
        row.operator('reset.regions', text = "Reset regions and shapes")


        row = layout.row()
        row = layout.row()
        split=layout.split()
        
#--------------------------
#Button Store preset
        box = layout.box()
        row = box.row()
        row.operator('load.preset', text = "Load preset")      
        row.operator('store.preset', text = "Store preset") 
#--------------------------        
#Button Result
        row = layout.row()
        row = layout.row()
        row = layout.row()
        row.operator('result.export', text = "Save this model as STL")
        row.operator('result.keep', text = "Save the blend") 
        rowdialog = layout.row()
        rowdialog.label(text="               aaaaaaaaaaaaaaa")

#-----------------------------------------------------------------------------------------
#FLOAT PROPERTIES----------------------------------------------

#bone scaling row 1 (sliders 1 to 3)
bpy.types.Object.my_mainh = FloatProperty(name = "Ear height", min=0.7, max=1.5, default=1.0, update = update_mainh)
bpy.types.Object.my_mainw = FloatProperty(name = "Ear width", min=0.5, max=1.6, default=1.0, update = update_mainw)
bpy.types.Object.my_maint = FloatProperty(name = "Ear thickness", min=0.5, max=1.4, default=1.0, update = update_maint)

#bone main rotations row 2 (sliders 4 to 6)
bpy.types.Object.my_mainz = FloatProperty(name = "Ear protrusion", min=-15, max=30, default=0, update = update_mainz)
bpy.types.Object.my_mainy = FloatProperty(name = "Ear verticality", min=-10, max=10, default=0, update = update_mainy)
bpy.types.Object.my_mainx = FloatProperty(name = "Ear tilt", min=-5, max=10, default=0, update = update_mainx)

#bone top rotations row 3 (sliders 7 to 9)
bpy.types.Object.my_topx = FloatProperty(name = "Top curving X", min=-7, max=30, default=0, update = update_topx)
bpy.types.Object.my_topy = FloatProperty(name = "Top curving Y", min=-7, max=30, default=0, update = update_topy)
bpy.types.Object.my_topz = FloatProperty(name = "Top curving Z", min=-7, max=30, default=0, update = update_topz)

#bone bottom rotations row 4 (sliders 10 to 12)
bpy.types.Object.my_bottomx = FloatProperty(name = "Bottom curving X", min=-10, max=10, default=0, update = update_bottomx)
bpy.types.Object.my_bottomy = FloatProperty(name = "Bottom curving Y", min=-10, max=10, default=0, update = update_bottomy)
bpy.types.Object.my_bottomz = FloatProperty(name = "Bottom curving Z", min=-10, max=10, default=0, update = update_bottomz)

#bone rear rotations row 5 (sliders 13 to 15)
bpy.types.Object.my_rearx = FloatProperty(name = "Rear curving X", min=-20, max=20, default=0, update = update_rearx)
bpy.types.Object.my_reary = FloatProperty(name = "Rear curving Y", min=-20, max=20, default=0, update = update_reary)
bpy.types.Object.my_rearz = FloatProperty(name = "Rear curving Z", min=-20, max=20, default=0, update = update_rearz)


#-------------SHAPEKEYS--------------------------------------
#shapekeys lobule row 1 (sliders 21 to 23)
bpy.types.Object.my_lobh = FloatProperty(name = "Lobule max", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_lobh)
bpy.types.Object.my_lobno = FloatProperty(name = "No lobule", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_lobno)
bpy.types.Object.my_lobt = FloatProperty(name = "Lobule thick", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_lobt)  

#shapekeys concavity, antihelix row 2 (sliders 24 to 26)
bpy.types.Object.my_conca = FloatProperty(name = "Rear concavity", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_conca)
bpy.types.Object.my_antid = FloatProperty(name = "Antihelix depth", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_antid)
bpy.types.Object.my_antir = FloatProperty(name = "Antihelix rear", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_antir)  

#shapekeys tubercle helix row 3 (sliders 27 to 29)
bpy.types.Object.my_tuber = FloatProperty(name = "Darwin tubercle", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_tuber)
bpy.types.Object.my_helixt = FloatProperty(name = "Helix thickness", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_helixt)
bpy.types.Object.my_helixp= FloatProperty(name = "Helix sharpness", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_helixp)  

#shapekeys tragus row 4 (sliders 30 to 32)
bpy.types.Object.my_tragh = FloatProperty(name = "Tragus protrusion", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_tragh)
bpy.types.Object.my_tragw = FloatProperty(name = "Tragus width", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_tragw)
bpy.types.Object.my_tragt = FloatProperty(name = "Tragus thick", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_tragt)  

#shapekeys notch, antitragus row 5 (sliders 33 to 35) 
bpy.types.Object.my_antit = FloatProperty(name = "Antitragus location", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_antit)
bpy.types.Object.my_antin = FloatProperty(name = "Antitragus notch", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_antin)
bpy.types.Object.my_notch= FloatProperty(name = "Lobule crease", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_notch)

#shapekeys antitragus loc, lob mid-crease row 6 (sliders 36 to 37)
bpy.types.Object.my_anti2 = FloatProperty(name = "Double antitragus", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_anti2)
bpy.types.Object.my_lobcr = FloatProperty(name = "Lobule mid crease", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_lobcr)

#shapekeys back of the ear row 7 (sliders 38 to 39)
bpy.types.Object.my_protr = FloatProperty(name = "Rear protrusion", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_protr)
bpy.types.Object.my_rearc = FloatProperty(name = "Root crease", min = 0, max = 1, soft_min=0, soft_max=1, default=0, update = update_rearc)


#--------------------------------------------------------------------------
#REGISTER     
classes = (EAR_PT_panel, RESET_PT_op, RESULTSTL_PT_op, RESULTBL_PT_op, CAPTIONS_PT_op, LEGEND_PT_op, MANUAL_PT_op, SUBSURF_PT_op,  RESETKEYS_PT_op, LOADPRESET_PT_op, SAVEPRESET_PT_op, MyProperties, MYTOOL_OT_write_data, ImportSomeData, ExportSomeData, AMAINH_PT_op, AMAINW_PT_op, AMAINT_PT_op, AMAINZ_PT_op, AMAINY_PT_op, AMAINX_PT_op, ATOPX_PT_op, ATOPY_PT_op, ATOPZ_PT_op, ABOTTOMX_PT_op, ABOTTOMY_PT_op, ABOTTOMZ_PT_op,  AREARX_PT_op, AREARY_PT_op, AREARZ_PT_op, ALOBH_PT_op, ALOBNO_PT_op, ALOBT_PT_op, ACONCA_PT_op, AANTID_PT_op, AANTIR_PT_op, ATUBER_PT_op, AHELIXP_PT_op, AHELIXT_PT_op, ATRAGH_PT_op, ATRAGW_PT_op, AANTIT_PT_op, AANTIN_PT_op, ANOTCH_PT_op, ATRAGT_PT_op, AANTI2_PT_op, ALOBCR_PT_op, APROTR_PT_op, AREARC_PT_op, HIDEA_PT_op,)


def register(): 
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.my_tool = PointerProperty(type=MyProperties)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)

    
def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.my_tool
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)


if __name__ == "__main__":
    register()